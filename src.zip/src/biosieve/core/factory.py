from __future__ import annotations

import inspect
from dataclasses import is_dataclass, fields
from typing import Any, Dict, Type


def instantiate_strategy(cls: Type[Any], params: Dict[str, Any]) -> Any:
    """
    Instantiate a strategy class with strict parameter validation.

    Unknown parameter keys raise ValueError to prevent silent typos.

    Parameters
    ----------
    cls:
        Strategy class (dataclass preferred).
    params:
        Parameter dictionary.

    Returns
    -------
    Any
        Instantiated strategy object.

    Raises
    ------
    ValueError
        If unknown keys are provided.
    """
    params = params or {}

    if is_dataclass(cls):
        allowed = {f.name for f in fields(cls)}
        unknown = set(params) - allowed
        if unknown:
            raise ValueError(f"Unknown parameters for {cls.__name__}: {sorted(unknown)}. Allowed: {sorted(allowed)}")
        return cls(**params)

    sig = inspect.signature(cls)
    allowed = set(sig.parameters.keys())
    unknown = set(params) - allowed
    if unknown:
        raise ValueError(f"Unknown parameters for {cls.__name__}: {sorted(unknown)}. Allowed: {sorted(allowed)}")
    return cls(**params)
